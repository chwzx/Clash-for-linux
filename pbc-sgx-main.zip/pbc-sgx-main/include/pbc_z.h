// ring of integers Z
// wrappers around GMP's mpz_t

//requires
// * field.h

#ifndef __PBC_FIELDMPZ_H__
#define __PBC_FIELDMPZ_H__

void field_init_z(field_ptr f);

#endif //__PBC_FIELDMPZ_H__
