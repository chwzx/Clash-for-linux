#ifndef PBC_INIT_RANDOM_H
#define PBC_INIT_RANDOM_H

void pbc_init_random(void);


#endif//PBC_INIT_RANDOM_H
